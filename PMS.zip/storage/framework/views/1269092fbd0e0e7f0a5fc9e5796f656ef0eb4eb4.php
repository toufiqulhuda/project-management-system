<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <h3 class="page-title">Change Password</h3>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('user')); ?>">User</a></li>
                <li class="breadcrumb-item active" aria-current="page"> Change Password</li>
            </ol>
        </nav>
    </div>
    <div class="panel-body">
        <?php if(session('error')): ?>
            <div class="alert alert-danger">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>
        <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
    </div>
    <div class="row">
        <div class="col-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-sm-6 col-md-6 col-lg-6">
                            <h4 class="card-title">Change Password</h4>
                            <p class="card-description">User can change himself password by this from </p>
                        </div>
                        <div class="col-sm-6 col-md-6 col-lg-6 text-sm-right text-md-right text-lg-right">






                        </div>
                    </div>
                    <form class="form-horizontal" method="POST" action="<?php echo e(route('changePassword')); ?>">
                        <?php echo e(csrf_field()); ?>


                        <div class="form-group<?php echo e($errors->has('current-password') ? ' has-error' : ''); ?> row">
                            <label for="new-password"
                                   class="col-md-4 control-label"><b><?php echo e(__('Current Password')); ?></b></label>

                            <div class="col-md-6">
                                <input id="current-password" type="password" class="form-control"
                                       name="current-password" required>

                                <?php if($errors->has('current-password')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('current-password')); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('new-password') ? ' has-error' : ''); ?> row">
                            <label for="new-password"
                                   class="col-md-4 control-label"><b><?php echo e(__('New Password')); ?></b></label>

                            <div class="col-md-6">
                                <input id="new-password" type="password" class="form-control" name="new-password"
                                       required>

                                <?php if($errors->has('new-password')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('new-password')); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="new-password-confirm"
                                   class="col-md-4 control-label"><b><?php echo e(__('Confirm New Password')); ?></b></label>

                            <div class="col-md-6">
                                <input id="new-password-confirm" type="password" class="form-control"
                                       name="new-password_confirmation" required>
                            </div>
                        </div>

                        <div class="form-group row">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-success">
                                    <i class="mdi mdi-content-save"></i> <?php echo e(__('Change Password')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\work\pms\laravel9-bootstrap5-vite\resources\views/user/changePassword.blade.php ENDPATH**/ ?>