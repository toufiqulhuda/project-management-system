<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <h3 class="page-title">User Profile</h3>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('user')); ?>">User</a></li>
                <li class="breadcrumb-item active" aria-current="page"> <?php echo e(Auth::user()->name); ?></li>
            </ol>
        </nav>
    </div>
    <div class="panel-body">
        <?php if(session('error')): ?>
            <div class="alert alert-danger">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>
        <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
    </div>
    <div class="row">
        <div class="col-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-sm-6 col-md-6 col-lg-6">
                            <h4 class="card-title">Edit User</h4>
                            <p class="card-description">Can edit user information </p>
                        </div>
                        <div class="col-sm-6 col-md-6 col-lg-6 text-md-right text-sm-right text-lg-right ">
                            <a href="<?php echo e(route('user')); ?>">
                                <button type="button"
                                        class="btn btn-icon-text mb-3  mb-sm-0 btn-inverse-primary font-weight-normal">
                                    <i class="mdi mdi-account-multiple btn-icon-prepend"></i> Goto User List
                                </button>
                            </a>
                        </div>
                    </div>
                    <?php if(!empty($users)): ?>
                    <form class="forms-sample" method="POST" action="<?php echo e(route('editUser')); ?>">
                        <?php echo e(csrf_field()); ?>


                        <div class="row">
                            <div class="col-sm-4 col-md-4 col-lg-4">
                                <img src="<?php echo e(asset(!empty($users->images) ? $users->images : '/images/face0.jpg')); ?>" alt="image" class="img-thumbnail">
                            </div>
                            <div class="col-sm-8 col-md-8 col-lg-8">

                                    <div class="row">
                                        <div class="form-group col-lg-12">
                                            <label for="name"><b><?php echo e(__('Full Name')); ?></b> <i class="mdi mdi-multiplication"></i></label>
                                            <input type="text" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="name" name="name" required
                                                   placeholder="Name" value="<?php echo e($users->name); ?>">
                                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="form-group col-lg-12">
                                            <label for="email"><b><?php echo e(__('E-mail')); ?></b> <i class="mdi mdi-multiplication"></i></label>
                                            <input type="text" class="form-control-plaintext" id="email" name="email" readonly
                                                   placeholder="Email" value="<?php echo e($users->email); ?>">
                                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="form-group col-lg-12">
                                            <label for="address"><b><?php echo e(__('Address')); ?></b> <i class="mdi mdi-multiplication"></i></label>
                                            <input type="text" class="form-control <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="address" name="address" required
                                                   placeholder="Address" value="<?php echo e($users->address); ?>">
                                            <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="form-group col-lg-12">
                                            <label for="contact"><b><?php echo e(__('Contact')); ?></b> <i class="mdi mdi-multiplication"></i></label>
                                            <input type="text" class="form-control <?php $__errorArgs = ['contact'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="contact" name="contact" required
                                                   placeholder="Contact" value="<?php echo e($users->contact); ?>">
                                            <?php $__errorArgs = ['contact'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>


                                    <div class="row">
                                        <div class="form-group col-lg-12">
                                            <label for="type"><b><?php echo e(__('User Type')); ?></b> <i class="mdi mdi-multiplication"></i></label>
                                            <select class="js-example-basic-single select2-hidden-accessible <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="type" name="type"
                                                    style="width: 100%;" data-select2-id="1" tabindex="-1" aria-hidden="true" required>
                                                <?php if(count($userTypeList)>0): ?>
                                                    <?php $__currentLoopData = $userTypeList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                        <option value="<?php echo e($userType['roleid']); ?>" <?php echo e(($users->type == $userType['roleid']) ? 'selected': ''); ?> ><?php echo e($userType['role_name']); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php else: ?>
                                                    <option value="">No type found</option>
                                                <?php endif; ?>
                                            </select>

                                            <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                <input type="hidden" name="id" value="<?php echo e($users->id); ?>">
                                <button type="submit" class="btn btn-primary mr-2"><i class="mdi mdi-content-save"></i> Save
                                </button>
                                <button class="btn btn-secondary"><i class="mdi mdi-close-circle-outline"></i> Close</button>
                            </div>
                        </div>
                    </form>
                    <?php else: ?>
                        <div class="alert alert-success">
                            No record found
                        </div>
                    <?php endif; ?>

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\work\pms\laravel9-bootstrap5-vite\resources\views/user/editUser.blade.php ENDPATH**/ ?>