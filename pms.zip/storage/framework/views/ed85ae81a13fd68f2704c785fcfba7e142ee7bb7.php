<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <h3 class="page-title">Manage Projects</h3>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('project')); ?>">Project</a></li>
                <li class="breadcrumb-item active" aria-current="page"> Project List</li>
            </ol>
        </nav>
    </div>
    <div class="panel-body">
        <?php if(session('error')): ?>
            <div class="alert alert-danger">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>
        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
    </div>
    <div class="row">
        <div class="col-xl-12 col-sm-12 col-md-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body px-0 overflow-auto">
                    <div class="row mr-0">
                        <div class="col-sm-7 col-md-7 col-lg-6">
                            <h5 class="card-title pl-4">Project's Table</h5>



                        </div>
                        <div class="col-sm-5 col-md-5 col-lg-6 text-md-right">
                            <?php if(Auth::user()->type == 3): ?>
                            <a href="<?php echo e(route('project-add')); ?>">
                                <button type="button"
                                        class="btn btn-icon-text mb-3 ml-4 mr-4 mb-sm-0 btn-inverse-primary font-weight-normal">
                                    <i class="mdi mdi-plus-circle-outline btn-icon-prepend"></i>Add New
                                </button>
                            </a>
                            <?php endif; ?>
                        </div>
                    </div>





















                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead class="bg-light">
                            <tr>
                                <th>#</th>
                                <th>Title</th>
                                <th>Instruction</th>
                                <th>Status</th>
                                <?php if(Auth::user()->type == 2): ?>
                                <th>Created By</th>
                                <th>Created At</th>
                                <th>Assigned To</th>
                                <?php elseif(Auth::user()->type == 3): ?>
                                <th>Publish</th>
                                <?php elseif(Auth::user()->type == 4): ?>
                                <th>Assigned By</th>
                                <th>Assigned At</th>
                                <?php endif; ?>
                                <th class="pr-4">Actions</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php if(count($projects)>0): ?>
                                <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <input class="" type="checkbox" value="<?php echo e($project->project_id); ?>" name="project_id[]" id="project_id">
                                            <?php echo e($project->project_id); ?>

                                        </td>
                                        <td><h5><a href="<?php echo e(route('project-details')); ?>?id=<?php echo e($project->project_id); ?>"><?php echo e($project->title); ?></a></h5></td>
                                        <td><?php echo e(Str::limit($project->description,100)); ?></td>
                                        <td><span class=" badge badge-pill badge-info"><?php echo e($project->status); ?></span></td>
                                        <?php if(Auth::user()->type == 3): ?>
                                        <td>
                                            <form class="form-horizontal" method="POST"
                                                  action="<?php echo e(route('project-publish')); ?>">
                                                <?php echo e(csrf_field()); ?>

                                                <input id="id" type="hidden" class="form-control" name="id"
                                                       value="<?php echo e($project->project_id); ?>" required>
                                                <?php if( $project->isactive ==1): ?>
                                                    <input id="status" type="hidden" class="form-control" name="status"
                                                           value="0" required>

                                                    <button type="submit" class=" badge badge-pill badge-inverse-success" <?php echo e(( $project->status == 1) || (Auth::user()->type==2) ? "disabled":""); ?> >
                                                        <i class="mdi mdi-account-check"></i> <?php echo e(__('Published')); ?>

                                                    </button>
                                                <?php else: ?>
                                                    <input id="status" type="hidden" class="form-control" name="status"
                                                           value="1" required>

                                                    <button type="submit" class=" badge badge-pill badge-inverse-danger "><i
                                                            class="mdi mdi-account-off"></i> <?php echo e(__('Draft')); ?>

                                                    </button>
                                                <?php endif; ?>
                                            </form>
                                        </td>
                                        <?php elseif(Auth::user()->type == 2): ?>
                                        <td><span class=" badge badge-pill badge-info"><?php echo e($project->created_by ?? ''); ?></span></td>
                                        <td><?php echo e($project->created_at ?? ''); ?></td>
                                        <td><span class=" badge badge-pill badge-info"><?php echo e($project->assigned_name ?? ''); ?></span></td>
                                        <?php elseif(Auth::user()->type == 4): ?>
                                            <td><span class=" badge badge-pill badge-info"><?php echo e($project->assigned_by_name ?? ''); ?></span></td>
                                            <td><?php echo e($project->assigned_at ?? ''); ?></td>
                                        <?php endif; ?>
                                        <td class="pr-4">
                                            <div class="dropdown">
                                                <button type="button" class="btn btn-outline-info dropdown-toggle"
                                                        id="dropdownMenuIconButton3" data-toggle="dropdown"
                                                        aria-haspopup="true" aria-expanded="false">
                                                    <i class="mdi mdi-settings"></i>
                                                </button>
                                                <div class="dropdown-menu" aria-labelledby="dropdownMenuIconButton3">
                                                    <h6 class="dropdown-header">Settings</h6>
                                                    <a class="dropdown-item"
                                                       href="<?php if((Auth::user()->type==3)&&($project->status==1)): ?>#<?php else: ?><?php echo e(route('project-edit')); ?>?id=<?php echo e($project->project_id); ?><?php endif; ?>"><i
                                                            class="mdi mdi-account-edit"></i> Edit</a>
                                                    <div class="dropdown-divider"></div>
                                                    <a class="dropdown-item" href="#"><i class="mdi mdi-delete"></i>
                                                        Delete</a>
                                                    <?php if(Auth::user()->type == 2): ?>
                                                    <div class="dropdown-divider"></div>
                                                    <a class="dropdown-item" data-bs-toggle="modal" data-bs-target="#exampleModal" href="" data-project-id="<?php echo e($project->project_id); ?>" onclick="get_project_id(this)"><i class="mdi mdi-delete"></i>
                                                        Assigned to</a>
                                                    <?php endif; ?>

                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="9">
                                        No project found
                                    </td>
                                </tr>

                            <?php endif; ?>
                            </tbody>
                        </table>
                    </div>


                </div>
            </div>
        </div>
    </div>
        <?php echo $projects->withQueryString()->links('pagination::bootstrap-5'); ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>

    <!-- Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Assigned an employee </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form method="POST" action="<?php echo e(route('project-assigned-to')); ?>">
                    <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="mb-3">
                        <div class="form-group">
                            <label for="assigned_to" class="form-label font-weight-bold" >Assigned To</label>
                            
                            <input type="hidden" name="ass_project_id" id="ass_project_id" value=""/>
                            <select class="js-example-basic-single select2-hidden-accessible <?php $__errorArgs = ['assigned_to'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="assigned_to" name="assigned_to" required
                                    style="width: 100%;" data-select2-id="1" tabindex="-1" aria-hidden="true" >
                                <option value="">...</option>
                                <?php if(!empty($assigned_users)): ?>
                                    <?php $__currentLoopData = $assigned_users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <option value=""> No user found </option>
                                <?php endif; ?>
                            </select>

                            <?php $__errorArgs = ['isactive'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" name="close" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" name="save" class="btn btn-primary">Save changes</button>
                </div>
                </form>
            </div>
        </div>
    </div>
    <script type="text/javascript">
        function get_project_id(c){
            var project_id = c.getAttribute('data-project-id');
            //alert(project_id);
            document.getElementById("ass_project_id").value = project_id;

        }

    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laragon\www\pms\resources\views/project/list.blade.php ENDPATH**/ ?>